#!/usr/bin/env python
# -*- coding:utf-8 -*-

##############################################################################
#
#
##############################################################################


from odoo import api, fields, models
from openerp.api import Environment as Env
import logging


class Bordereau(models.AbstractModel):
    _name = 'report.nh_voucher_from_cash_and_bank_ce.report_bordereau'

    @api.model
    def render_html(self, docids, data=None):
        a=1
        docargs = {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'data': data['elements'],
            # 'sale_person_van_id': data['elements']['sale_person_van_id'],
            # 'sale_person_id': data['elements']['sale_person_id'],
        }
        return self.env['report'].render('nh_voucher_from_cash_and_bank_ce.report_bordereau', docargs)

    @api.multi
    def get_report_values(self, docids, data=None):
        docargs = {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'data': data['elements'],

        }
        return docargs




