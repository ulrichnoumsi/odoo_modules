# -*- coding: utf-8 -*-


from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)

_account_prefix = "58"


class AccountMove(models.Model):
    _inherit = "account.move"

    @api.multi
    def post(self):
        payement_name = False
        res = super(AccountMove, self).post()
        ref = self.ref
        refs = []
        for l in self.line_ids:
            payement_name = l.payment_id.name
        if payement_name:
            self.write({'name': payement_name})
        if ref:
            refs = ref.split('-')
            if len(refs) > 1:
                self.write({'ref': refs[1]})

        return res
