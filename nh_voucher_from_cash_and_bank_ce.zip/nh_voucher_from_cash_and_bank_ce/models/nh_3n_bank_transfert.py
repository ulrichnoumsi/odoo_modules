# -*- coding: utf-8 -*-


from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)


class BankTransfert(models.Model):
    _name = "nh.3n.bank.transfert"
    _description = "Bank transfert operations"

    name = fields.Char('Name')
    ref = fields.Char('Reference')
    statement_line_id = fields.Many2one('account.bank.statement.line', 'Cash-Line')
    statement_line_dest_id = fields.Many2one('account.bank.statement.line', 'Created line in Destination Journal')
    amount = fields.Monetary("Amount", currency_field='devise_id')
    devise_id = fields.Many2one('res.currency', 'Currency')

    debit = fields.Float("Debit")
    credit = fields.Float("Credit")
    date = fields.Date(string="Date", default=datetime.today())
    branch_id = fields.Many2one('res.branch', 'Branch')
    partner_id = fields.Many2one('res.partner', 'Partner')
    journal_id = fields.Many2one('account.journal', 'Journal')
    journal_src_id = fields.Many2one('account.journal', 'Source Journal', store=True, compute='_get_journal_src_id')
    account_id = fields.Many2one('account.account', 'Account')
    state = fields.Selection(
        selection=[("draft", "Draft"),
                   ("confirm", "Confirm"),
                   ("cancel", "Reject"),

                   ], string="State", readonly=True, default="draft")
    transaction_type = fields.Selection(selection=[("cash_cash", "Cash - Cash"),
                                                   ("cash_bank", "Cash - Bank"),
                                                   ("bank_cash", "Bank - Cash"),
                                                   ("bank_bank", "Bank - Bank")],
                                        string="Type Transaction")

    company_id = fields.Many2one('res.company', related='journal_id.company_id', string='Company', store=True,
                                 readonly=True)

    # computes fields
    @api.depends('statement_line_id')
    @api.one
    def _get_journal_src_id(self):
        if self.statement_line_id:
            self.journal_src_id = self.statement_line_id.statement_id.journal_id

    # Constraints methods

    def check_bank_journal(self):
        obj_bank_statem = self.env["account.bank.statement"]
        bj = obj_bank_statem.search([('journal_id', '=', self.journal_id.id), ('state', '=', 'open')], limit=1)
        res = 0
        if bj:
            res = bj.id
        return res

    def _create_statement_line_in_dst_journal(self, bank_id):
        vals = {
            'partner_id': self.partner_id.id,
            'ref': self.ref,
            'date': self.date,
            'name': self.name,
            'amount': self.amount,
            'statement_id': bank_id
        }
        res = self.env["account.bank.statement.line"].create(vals)
        self.write({
            'statement_line_dest_id': res.id
        })
        return res

    def bank_cash_transfert_print(self):
        self.ensure_one()
        return self.env.ref('nh.3n.bank.transfert').report_action(self)

    @api.multi
    def action_confirm(self):
        for rec in self:
            dest_journal = rec.check_bank_journal()
            if dest_journal == 0:
                raise UserError('No Open bank journal available,\nCreate one before')
            line_id = rec._create_statement_line_in_dst_journal(dest_journal)
            # after reconcile the line created with the initial transit account
            counterpart_aml_dicts = []
            new_aml_dicts = [
                {
                    'branch_id': rec.branch_id,
                    'partner_id': rec.partner_id.id,
                    'account_id': rec.account_id.id,
                    'credit': rec.amount,
                    'debit': 0,
                    'name': rec.name
                }
            ]
            payment_aml_ids = []
            line_id.process_reconciliation(counterpart_aml_dicts, payment_aml_ids, new_aml_dicts)
            self.write({
                'state': 'confirm'
            })
        return True

    @api.multi
    def action_print_bord(self):

        elements = {
            'branch_id_': self.branch_id.name,
            'ref_': self.ref,
            'amount_': self.amount,
            'name_': self.name,
            'date_': self.date
        }
        datas = {
            'ids': self.ids,
            'model': 'bank_cash.report_bordereau',
            'elements': elements,
        }

        return {
            'type': 'ir.actions.report',
            'name': 'nh_voucher_from_cash_and_bank_ce.report_bordereau',
            'res_model': 'report.nh_voucher_from_cash_and_bank_ce.report_bordereau',
            'model': 'report.nh_voucher_from_cash_and_bank_ce.report_bordereau',
            'report_type': 'qweb-pdf',
            'report_name': 'nh_voucher_from_cash_and_bank_ce.report_bordereau',
            'data': datas,
        }

    def action_reject(self):
        """
         Cette fonction annule un bank transfert
         le but est d'effectuer le lettrage inverse ayant initié le bank transfert
        :return:
        """
        # création de la ligne de caisse inverse
        statement_obj = self.env['account.bank.statement.line']
        vals = {}
        statement = statement_obj.search([('id', '=', self.statement_line_id.id)], limit=1).statement_id
        vals.update(
            {
                'partner_id': self.partner_id.id,
                'name': str(self.name) + "-Rejected",
                'amount': self.amount,
                'date': self.date,
                'branch_id': statement.branch_id.id,
                'statement_id': statement.id
            }
        )

        reverse_statement_line = statement_obj.create(vals)
        # Reconciliation of the line created with the initial transit account
        counterpart_aml_dicts = []
        new_aml_dicts = [
            {
                'branch_id': vals['branch_id'],
                'partner_id': vals['partner_id'],
                'account_id': self.account_id.id,
                'credit': self.amount,
                'debit': 0, 'name': vals['name']
            }
        ]
        payment_aml_ids = []
        reverse_statement_line.process_reconciliation(counterpart_aml_dicts, payment_aml_ids, new_aml_dicts)
        # mise à jour de l'état du transfert à "annulé"
        self.write({'state': 'cancel'})

    @api.multi
    def action_reset_to_draft(self):
        for rec in self:
            dst_statement_line = rec.statement_line_dest_id
            if not dst_statement_line:
                dst_statement_line = self.env['account.bank.statement.line'].search([
                    ('ref', '=', self.ref),
                    ('amount', '=', self.amount),
                    ('date', '=', self.date),
                    ('partner_id', '=', self.partner_id.id),
                    ('statement_id.journal_id', '=', self.journal_id.id)
                ])
                if not dst_statement_line:
                    raise UserError(_('This Transfer is not related to any statement line'))
            dst_statement_line[0].button_cancel_reconciliation()
            # clear unexpected move_lines
            moves = self.env['account.move'].search([
                ('line_ids.ref', '=', self.ref),
                ('line_ids.account_id', '=', self.account_id.id),
                ('line_ids.credit', '=', self.amount),
                ('date', '=', self.date),
                ('partner_id', '=', self.partner_id.id),
                ('line_ids.journal_id', '=', self.journal_id.id)
            ])
            for move in moves:
                move.button_cancel()
                move.unlink()
            dst_statement_line[0].unlink()
            self.write({'state': 'draft'})
