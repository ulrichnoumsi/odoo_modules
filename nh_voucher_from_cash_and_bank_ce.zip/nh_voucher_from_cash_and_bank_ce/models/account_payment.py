# -*- coding: utf-8 -*-


from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)

_account_prefix = "58"


class AccountPayment(models.Model):
    _inherit = "account.payment"

    @api.model
    def create(self, vals):
        if vals['partner_type'] == "customer":
            vals['name'] = self.env['ir.sequence'].next_by_code("account.payment.customer.invoice")
        else:
            vals['name'] = self.env['ir.sequence'].next_by_code("account.payment.supplier.invoice")

        return super(AccountPayment, self).create(vals)
