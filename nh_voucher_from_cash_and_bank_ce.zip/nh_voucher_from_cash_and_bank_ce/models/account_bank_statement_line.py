# -*- coding: utf-8 -*-


from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)


class AccountBankStatementLine(models.Model):
    _inherit = "account.bank.statement.line"

    @api.multi
    def process_reconciliations(self, data):
        """

        :param data:
        :return: Crée un Bank Transfert en cas de mouvement de la caisse vers la banque en passant par
         le compte de transit
        """
        res = super(AccountBankStatementLine, self).process_reconciliations(data)
        transfert_obj = self.env['nh.3n.bank.transfert']
        vals = {}
        if len(data[0]['counterpart_aml_dicts']) == 0:  # and self.statement_id.journal_id.type == 'cash':
            new_aml_dicts = data[0]['new_aml_dicts']
            for d in new_aml_dicts:
                if 'account_id' in d:
                    account = self.env['account.account'].search([('id', '=', d['account_id'])])
                    account_id = account.id
                    if account.is_transit and d['debit'] != 0.0 and self.journal_id.enable_bank_cash:
                        partner_id = self.partner_id.id
                        journal = self.env['account.journal'].search([('partner_id', '=', partner_id)], limit=1)
                        type_operation = ""

                        if journal.type == 'bank':
                            if self.statement_id.journal_id.type == 'cash':
                                type_operation = "cash_bank"
                            else:
                                type_operation = "bank_bank"

                        if journal.type == 'cash':
                            if self.statement_id.journal_id.type == 'bank':
                                type_operation = "bank_cash"
                            else:
                                type_operation = "cash_cash"

                        if len(journal) != 1:
                            raise UserError('You must associate the partner %s'
                                            ' on a cash or bank journal' % self.partner_id.display_name)
                        if journal:  # and journal.type in ['bank']:
                            vals['account_id'] = account_id
                            vals['branch_id'] = self.statement_id.branch_id.id
                            vals['partner_id'] = self.partner_id.id
                            vals['journal_id'] = journal.id
                            vals['debit'] = d['debit']
                            vals['credit'] = d['credit']
                            vals['statement_line_id'] = self.id
                            vals['name'] = d['name']
                            vals['ref'] = self.ref
                            vals['amount'] = abs(d['debit'] - d['credit'])
                            vals['transaction_type'] = type_operation
                            vals['date'] = self.date
                            transfert_obj.create(vals)

        return res
