from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)


class AccountAccount(models.Model):
    _inherit = "account.account"

    is_transit = fields.Boolean('Is Transit')

    @api.onchange('code')
    def onchange_code(self):
        prefixes = self.env['ir.config_parameter'].get_param('transit_account_prefix')
        #prefixes = str(prefs.value)
        prefixes_list = []
        if prefixes:
            for prefix in prefixes.split(";"):
                prefixes_list.append(prefix)
                if self.code and self.code.startswith(prefix):
                    self.is_transit = True