# -*- coding: utf-8 -*-


from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)


class AccountBankStatement(models.Model):
    _inherit = "account.bank.statement"

    @api.model
    def create(self, vals):

        obj_journal = self.env['account.journal']
        journal = obj_journal.browse(vals['journal_id'])
        vals['name'] = self.env['ir.sequence'].next_by_code(journal.code)
        if not vals['name']:
            raise UserError('No sequence define for the current journal\n please check')

        return super(AccountBankStatement, self).create(vals)

    @api.multi
    def button_confirm_bank(self):
        if self.pos_session_id == False:
            balance = 0
            for st_line in self.browse(self.id).line_ids:
                if st_line.journal_entry_ids:
                    for mv_line in st_line.journal_entry_ids:
                        if mv_line.account_id.is_transit and mv_line.branch_id.id == self.branch_id.id:
                            account_id = mv_line.account_id.id
                            branch_id = self.branch_id.id
                            balance = sum(line.debit for line in mv_line.search(
                                ['&', ('account_id', '=', account_id), ('branch_id', '=', branch_id)])) - \
                                      sum(line.credit for line in mv_line.search(
                                          ['&', ('account_id', '=', account_id), ('branch_id', '=', branch_id)]))
                else:
                    raise UserError('Cannot close when there are at least one unreconciled line')

            if balance != 0:
                raise UserError("Connot close with unbalance transit account!\n" + str(balance))

        return super(AccountBankStatement, self).button_confirm_bank()
