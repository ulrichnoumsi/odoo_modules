# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import UserError
from datetime import datetime
import logging
from odoo.exceptions import RedirectWarning, UserError, ValidationError

_logger = logging.getLogger(__name__)


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    partner_id = fields.Many2one('res.partner', 'Partner')
    enable_bank_cash = fields.Boolean('Enable Bank/Cash Transfert', default=True)
    code = fields.Char(string='Short Code', size=10, required=True,
                       help="The journal entries of this journal will be named using this prefix.")

    @api.model
    def create(self, vals):
        journal = super(AccountJournal, self).create(vals)
        code_seq = journal.code
        sequence = self.sudo(1).env['ir.sequence'].browse(journal.sequence_id.id)
        sequence.write({
            'code': code_seq
        })

        return journal
